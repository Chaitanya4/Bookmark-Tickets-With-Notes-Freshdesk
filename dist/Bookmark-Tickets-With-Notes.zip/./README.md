## Bookmark Tickets

Bookmark Tickets is an app which allows agents to bookmark a couple of tickets with personal notes and revisit them whenever they want to. 

Bookmark Tickets stores the ticket bookmarked with notes. It will help agent to remember and revisit tickets important to them. Notes Associated with tickets will help the agent to remember customer response or detailed requirement.
Now, easily handle multiple important tickets using Bookmark Tickets.